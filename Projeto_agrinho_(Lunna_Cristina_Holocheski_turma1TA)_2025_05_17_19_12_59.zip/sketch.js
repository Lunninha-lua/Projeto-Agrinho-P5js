let crescimento = 0;
let fases = [
  "Semente ^--^",
  "Broto ;-;",
  "Planta Jovem",
  "Planta Adulta",
  "Pronta para Colheita $_$",
];

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
}
function draw() {
  background(190, 200, 180);

  // Desenhar o solo
  fill(160, 90, 40);
  rect(0, height - 100, width, 100);

  // Crescimento da soja
  drawSoja(crescimento);

  // Informações na tela
  fill(0);
  textSize(20);
  text("Fase: " + fases[crescimento], width / 2, 30);
  text(
    "Clique na tela pfv para avançar o crescimento ^--^",
    width / 2,
    height - 40
  );
}
function drawSoja(fase) {
  let x = width / 2;
  let yBase = height - 100;

  stroke(1);
  fill(1, 240, 1);

  if (fase >= 1) {
    line(x, yBase, x, yBase - 75); // caule
  }
  if (fase >= 2) {
    ellipse(x, yBase - 50, 15, 9); // primeiras folhas
  }
  if (fase >= 3) {
    ellipse(x - 10, yBase - 60, 25, 10); // mais folhas
    ellipse(x + 10, yBase - 60, 25, 10);
  }
  if (fase >= 4) {
    ellipse(x - 15, yBase - 80, 30, 15); // planta madura
    ellipse(x + 15, yBase - 80, 30, 15);
  }
}

function mousePressed() {
  if (crescimento < fases.length - 1) {
    crescimento++;
  }
}
